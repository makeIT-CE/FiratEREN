﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Project
{
    public partial class Form1 : MaterialForm
    {
        private MaterialSkinManager skinManager;

        public Form1()
        {
            InitializeComponent();

                    
                    ColorScheme colorScheme = new ColorScheme(
            Primary.Teal800, Primary.Teal900,
            Primary.Teal900, Accent.Pink200,
            TextShade.WHITE);


            skinManager = MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = colorScheme;

            
            ApplyColorSchemeToControls(colorScheme, Controls);
        }

        private void ApplyColorSchemeToControls(ColorScheme colorScheme, Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is Control materialControl)
                {
                    materialControl.BackColor = colorScheme.PrimaryColor;
                    materialControl.ForeColor = colorScheme.TextColor;
                }

                ApplyColorSchemeToControls(colorScheme, control.Controls);
            }
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            string adminFilePath = "admin.csv";
            string username = txtUserName.Text;
            string password = txtPassword.Text;

            if (CheckAdminCredentials(adminFilePath, username, password))
            {
                Form2 form2 = new Form2();
                form2.Show();
                Hide();
            }
            else
            {
                MessageBox.Show(
                    "Invalid username or password. Please try again.",
                    "Login Failed",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private bool CheckAdminCredentials(string adminFilePath, string username, string password)
        {
            string[] adminRecords = File.ReadAllLines(adminFilePath);

            foreach (string record in adminRecords)
            {
                string[] fields = record.Split('|');
                string storedUsername = fields[0];
                string storedPassword = fields[1];

                if (username == storedUsername && password == storedPassword)
                {
                    return true;
                }
            }

            return false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
