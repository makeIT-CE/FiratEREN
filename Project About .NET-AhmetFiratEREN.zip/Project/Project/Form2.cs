﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace Project
{
    public partial class Form2 : MaterialForm
    {
        private const string videoFilePath = "video.csv";
        private Timer timer;
        private int totalSavedVideos;
        private int totalDeletedVideos;
        private DateTime lastUpdateDate;
        private string videoId;
        private bool isDeleted;
        private MaterialSkinManager skinManager;

        public Form2()
        {
                            InitializeComponent();
                    ColorScheme colorScheme = new ColorScheme(
                    Primary.Teal800, Primary.Teal900,
                    Primary.Teal900, Accent.Pink200,
                    TextShade.WHITE);


            skinManager = MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = colorScheme;


           
            listVideoSelected.BackColor = colorScheme.PrimaryColor;
            listVideoSelected.ForeColor = colorScheme.TextColor;
            listVideoSelected.Anchor = AnchorStyles.None;

            listVideo.BackColor = colorScheme.PrimaryColor;
            listVideo.ForeColor = colorScheme.TextColor;
            listVideo.Anchor = AnchorStyles.None;


            lblAdmin.BackColor = colorScheme.PrimaryColor;
            lblAdmin.ForeColor = colorScheme.TextColor;
            lblAdmin.Anchor = AnchorStyles.None;

            btnAddVideo.BackColor = colorScheme.PrimaryColor;
            btnOpen.BackColor = colorScheme.PrimaryColor;
            btnUpdate.BackColor = colorScheme.PrimaryColor;
            btnDelete.BackColor = colorScheme.PrimaryColor;



            ApplyColorSchemeToControls(colorScheme, Controls);

            timer = new Timer();
            timer.Interval = 15000;
            timer.Tick += timer1_Tick;
            timer.Start();

            LoadVideoListView();
        }

        private void ApplyColorSchemeToControls(ColorScheme colorScheme, Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is MaterialSkin.Controls.MaterialLabel materialLabel)
                {
                    materialLabel.ForeColor = colorScheme.TextColor;
                }
                else if (control is MaterialRaisedButton materialButton)
                {
                    materialButton.BackColor = colorScheme.PrimaryColor;
                    materialButton.ForeColor = colorScheme.TextColor;
                }

                ApplyColorSchemeToControls(colorScheme, control.Controls);
            }
        }

        private void LoadVideoListView()
        {
            listVideo.Items.Clear();
            string[] videoRecords = File.ReadAllLines(videoFilePath);

            foreach (string record in videoRecords)
            {
                string[] fields = record.Split('|');
                string id = fields[0];
                string link = fields[1];
                string dateAdded = fields[2];
                string description = fields[3];
                int isDeleted = (fields[4] == "1") ? 1 : 0;

                if (isDeleted == 0)
                {
                    ListViewItem item = new ListViewItem(id);
                    item.SubItems.Add(link);
                    item.SubItems.Add(description);
                    item.SubItems.Add(dateAdded);
                    listVideo.Items.Add(item);
                    
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LoadVideoListView();
            UpdateInformationLabel();
        }

        private void UpdateInformationLabel()
        {
            int totalVideos = listVideo.Items.Count;
            totalSavedVideos = totalVideos - totalDeletedVideos;
            lastUpdateDate = DateTime.Now;

            lblInfo.Text = $"There are {totalSavedVideos} saved videos. There are also {totalDeletedVideos} deleted videos. " +
                $"Last update date is {lastUpdateDate.ToString("yyyy.MM.dd HH:mm")}.";

            lblDate.Text = $"created Date {lastUpdateDate.ToString("yyyy.MM.dd HH:mm")}.";
        }

        private void btnAddVideo_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void listVideoSelected_Enter(object sender, EventArgs e)
        {

            if (listVideo.SelectedItems.Count > 0)
            {
                string id = listVideo.SelectedItems[0].Text;
                string link = listVideo.SelectedItems[0].SubItems[1].Text;
                string dateAdded = listVideo.SelectedItems[0].SubItems[2].Text;
                string description = listVideo.SelectedItems[0].SubItems[3].Text;
                string thumbnailUrl = $"https://img.youtube.com/vi/{id}/default.jpg";

                try
                {
                    pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;  
                    pictureBox.Load(thumbnailUrl);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error loading image: {ex.Message}");
                }
            }
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {
            if (listVideo.SelectedItems.Count > 0)
            {
                string link = listVideo.SelectedItems[0].SubItems[1].Text;
                Process.Start(link);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (listVideo.SelectedItems.Count > 0)
            {
                string id = listVideo.SelectedItems[0].Text;
                string link = listVideo.SelectedItems[0].SubItems[1].Text;
                string dateAdded = listVideo.SelectedItems[0].SubItems[2].Text;
                string description = listVideo.SelectedItems[0].SubItems[3].Text;

                Form4 form4 = new Form4(id, link,description);
                form4.ShowDialog();
            }
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listVideo.SelectedItems.Count > 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to remove this video?", "Confirmation",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string id = listVideo.SelectedItems[0].Text;
                    UpdateVideoDeletedStatus(id, true);
                    totalDeletedVideos++;
                    UpdateInformationLabel();
                }
            }
        }

        private void UpdateVideoDeletedStatus(string id, bool isDeleted)
        {
            string[] videoRecords = File.ReadAllLines(videoFilePath);

            for (int i = 0; i < videoRecords.Length; i++)
            {
                string[] fields = videoRecords[i].Split('|');
                string currentId = fields[0];
                int deletedStatus;

                if (currentId == id && int.TryParse(fields[4], out deletedStatus))
                {
                    videoRecords[i] = $"{currentId}|{fields[1]}|{fields[2]}|{fields[3]}|{(isDeleted ? 1 : deletedStatus)}";
                }
            }

            File.WriteAllLines(videoFilePath, videoRecords);
        }

        private void listVideo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
