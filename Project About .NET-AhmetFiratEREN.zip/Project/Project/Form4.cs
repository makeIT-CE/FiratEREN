﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;
using static System.Windows.Forms.LinkLabel;

namespace Project
{
    public partial class Form4 :MaterialForm
    {

        private string videoId;
        private string videoLink;
        private string videoDescription;
        private MaterialSkinManager skinManager;
        public Form4(string id, string link, string description)
        {
            InitializeComponent();
            ColorScheme colorScheme = new ColorScheme(
          Primary.Teal800, Primary.Teal900,
          Primary.Teal900, Accent.Pink200,
          TextShade.WHITE);


            skinManager = MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkinManager.Themes.DARK;
            skinManager.ColorScheme = colorScheme;

            lblAdmin.BackColor = colorScheme.PrimaryColor;
            lblAdmin.ForeColor = colorScheme.TextColor;
            lblAdmin.Anchor = AnchorStyles.None;

            lblYouId.BackColor = colorScheme.PrimaryColor;
            lblYouLink.BackColor = colorScheme.PrimaryColor;
            lblDesc.BackColor = colorScheme.PrimaryColor;

            txtId.BackColor = colorScheme.PrimaryColor;
            txtId.ForeColor = colorScheme.TextColor;
            txtId.Anchor = AnchorStyles.None;

            txtLink3.BackColor = colorScheme.PrimaryColor;
            txtLink3.ForeColor = colorScheme.TextColor;
            txtLink3.Anchor = AnchorStyles.None;

            txtDesc.BackColor = colorScheme.PrimaryColor;
            txtDesc.ForeColor = colorScheme.TextColor;
            txtDesc.Anchor = AnchorStyles.None;

            btnCancelVideo.BackColor = colorScheme.PrimaryColor;
            btnSave.BackColor = colorScheme.PrimaryColor;

            ApplyColorSchemeToControls(colorScheme, Controls);

            videoId = id;
            videoLink = link;
            videoDescription = description;

            txtId.Text = videoId;
            txtLink3.Text = videoLink;
            txtDesc.Text = videoDescription;



        }



        private void ApplyColorSchemeToControls(ColorScheme colorScheme, Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is MaterialLabel materialLabel)
                {
                    materialLabel.BackColor = colorScheme.PrimaryColor;
                    materialLabel.ForeColor = colorScheme.TextColor;
                }
                else if (control is MaterialRaisedButton materialButton)
                {
                    materialButton.BackColor = colorScheme.PrimaryColor;
                    materialButton.ForeColor = colorScheme.TextColor;
                }
                else if (control.Controls.Count > 0)
                {
                    ApplyColorSchemeToControls(colorScheme, control.Controls);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtId.Text) || string.IsNullOrWhiteSpace(txtLink3.Text) || string.IsNullOrWhiteSpace(txtDesc.Text))
            {
                MessageBox.Show("Please fill in all the fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtId.Text.Contains("|") || txtLink3.Text.Contains("|") || txtDesc.Text.Contains("|"))
            {
                MessageBox.Show("Fields cannot contain the '|' character.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                string[] videoRecords = File.ReadAllLines("Video.csv");
                for (int i = 0; i < videoRecords.Length; i++)
                {
                    string[] fields = videoRecords[i].Split('|');
                    string currentId = fields[0];

                    if (currentId == videoId)
                    {
                        videoRecords[i] = $"{txtId.Text}|{txtLink3.Text}|{txtDesc.Text}|{DateTime.Now.ToString("yyyy.MM.dd HH:mm")}|0";
                        break;
                    }
                }

                File.WriteAllLines("Video.csv", videoRecords);

                MessageBox.Show("Video updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while updating the video: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btnCancelVideo_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
    }

