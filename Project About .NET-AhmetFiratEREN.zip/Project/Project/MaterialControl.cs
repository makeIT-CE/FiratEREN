﻿namespace Project
{
    internal class MaterialControl
    {
    }
}