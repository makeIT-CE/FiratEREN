﻿namespace System.Web
{
    internal class HttpUtility
    {
        internal static object ParseQueryString(string query)
        {
            throw new NotImplementedException();
        }
    }
}